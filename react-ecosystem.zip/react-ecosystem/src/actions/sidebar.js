import AjaxWrapper from '../api/AjaxWrapper';

export const SET_USER_DETAILS = 'SET_USER_DETAILS';
export const SET_LOADER = 'SET_LOADER';

export const setUsers = (users) => {
  return {
    type: SET_USER_DETAILS,
    payload: users
  }
}

const setLoader = (loader) => {
  return {
    type: SET_LOADER,
    payload: loader
  }
}

const getUserDetails = (url) => {
  return (dispatch) => {
    dispatch(setLoader(true));
    AjaxWrapper.get(url).then((response) => {
      dispatch(setLoader(false));
      dispatch(setUsers(response.results));
    });
  };
};

export {getUserDetails}