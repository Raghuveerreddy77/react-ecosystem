import React, {Fragment} from 'react';
import Modal from '../modal/Modal';
import './UserDetails.scss';

const UserDetails = ({open = false, toggleModal, userDetails}) => {
  return (
    <Fragment>
      {
        open &&
        <Modal>
          <div className="modal">
            <div className="modal-content">
              <span className="close" onClick={toggleModal}>&times;</span>
              {
                userDetails.name &&
                <div className='user-card'>
                  <div className='user-card--top'>
                    <img src={userDetails.picture.large} alt='user'/>
                  </div>
                  <hr />
                  <div className='user-card--bottom'>
                    <p>Name : <span>{userDetails.name.first} {userDetails.name.last}</span></p>
                    <p>Location : <span>{userDetails.location.country}</span></p>
                    <p>State : <span>{userDetails.location.state}</span></p>
                    <p>City : <span>{userDetails.location.city}</span></p>
                    <p>Email : <span>{userDetails.email}</span></p>
                    <p>Phone No. : <span>{userDetails.phone}</span></p>
                  </div>
                </div>
              }
            </div>
          </div>
        </Modal>
      }
    </Fragment>
  );
}

export default UserDetails;