import React from 'react';
import { render } from '@testing-library/react';
import UserDetails from './UserDetails';

describe('UserDetails test cases', () => {
  const defaultProps = {
    userDetails: {},
    toggleModal: jest.fn(),
    open: false
  }

  test('renders UserDetails correctly', () => {
    const { asFragment } = render(<UserDetails {...defaultProps}/>);
    expect(asFragment()).toMatchSnapshot();
  });
});
