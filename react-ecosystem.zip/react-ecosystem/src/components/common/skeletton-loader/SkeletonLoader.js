import React from 'react';
import ContentLoader from 'react-content-loader';

export const Circle = ({radius, hPosition, vPosition}) => {
  const figureRadius = radius || 7;
  const figureHPosition = hPosition || figureRadius;
  const figureVPosition = vPosition || figureRadius;
  return <circle cx={figureHPosition} cy={figureVPosition} r={figureRadius}/>;
};

export const Rectangle = ({height, width, hPosition, vPosition, xRadius, yRadius}) => {
  const figureHeight = height || 15;
  const figureWidth = width || 250;
  const figureHPosition = hPosition || 0;
  const figureVPosition = vPosition || 0;
  const figureXRadius = xRadius || 0;
  const figureYRadius = yRadius || 0;
  return (
    <rect
      x={figureHPosition}
      y={figureVPosition}
      rx={figureXRadius}
      ry={figureYRadius}
      width={figureWidth}
      height={figureHeight}
    />
  );
};

export default (props) => {
  const defaultProps = {
    foregroundColor: '#F3F3F3',
    backgroundColor: '#173c77',
    animate: true,
    className: 'skeleton-loader'
  };
  return <ContentLoader {...defaultProps} {...props} />;
};
