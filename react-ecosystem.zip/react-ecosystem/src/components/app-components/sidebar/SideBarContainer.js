import {connect} from 'react-redux';

import SideBar from './SideBar';
import {
  getUserDetails
} from '../../../actions/sidebar';

export const mapStateToProps = (state) => {
  return {
    isFetching: state.users.isFetching
  };
};

export const mapDispatchToProps = dispatch => ({
  getUserDetails: (url) => {
    dispatch(getUserDetails(url));
  }
});

export default connect(mapDispatchToProps, mapDispatchToProps)(SideBar);
