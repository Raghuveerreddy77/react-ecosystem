import React, {useState} from 'react';
import './Sidebar.scss';
import Input from '../../common/input/Input';

const SideBar = ({getUserDetails}) => {
  const [input, setInput] = useState(0);

  const handleChange = (no) => setInput(no);

  const handleSearch = () => {
    if (input >= 0 && input <= 20) {
      getUserDetails(input);
    }
  }
  return (
    <div className='side-bar'>
      <div className='tabs-container'>
        <div className='tabs-wrapper'>
          <div className='tab'>
            <div>Enter number to retrive User Profile</div>
            <Input
              className='input-number'
              type='number'
              placeholder='Enter number'
              defaultValue={0}
              min={0}
              max={20}
              errorMsg='Please enter valid number'
              onChange={handleChange}
              isMandatory
            />
            <button className='btn btn-primary' onClick={handleSearch}>Search</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SideBar;