import React, {Fragment} from 'react';
import SkeletonLoader, { Circle, Rectangle } from '../../../common/skeletton-loader/SkeletonLoader';

const LoaderItem = () => {
  return (
    <div className='user-card'>
      <div className='user-card--top'>
      <SkeletonLoader height={140} width={237}>
        <Circle radius={60} vPosition={70} hPosition={98}/>
      </SkeletonLoader>
      </div>
      <hr />
      <div className='user-card--bottom'>
        <SkeletonLoader height={140} width={237}>
          <Rectangle height={15} width={177} hPosition={10} vPosition={0}/>
          <Rectangle height={12} width={107} hPosition={50} vPosition={24}/>
        </SkeletonLoader>
      </div>
    </div>
  );
}

const Loader = () => {
  return (
    <Fragment>
      <LoaderItem />
      <LoaderItem />
      <LoaderItem />
      <LoaderItem />
    </Fragment>
  );
}

export default Loader;