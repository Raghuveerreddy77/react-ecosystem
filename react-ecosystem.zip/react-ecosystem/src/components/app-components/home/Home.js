import React, {memo, Fragment, useState} from 'react';
import './Home.scss';
import Loader from './loader/Loader';
import UserDetails from '../../common/user-details/UserDetails';

const Home = ({users, isFetching}) => {
  const [showModal, setModal] = useState(false);
  const [user, setUser] = useState({});
  let componentToBeRender = <Loader />;

  const handleUserClick = (value) => {
    setUser(value);
    setModal(!showModal);
  }

  if (isFetching && users.length === 0) {
    componentToBeRender = <div className='default-message'>Note : Please click search button to see user details</div>
  }

  if (!isFetching) {
    componentToBeRender = (
      <Fragment>
        {
          users.map((user) => {
            return (
              <div className='user-card' key={user.login.uuid} onClick={() => handleUserClick(user)}>
                <div className='user-card--top'>
                  <img src={user.picture.large} alt='user'/>
                </div>
                <hr />
                <div className='user-card--bottom'>
                  <h3>My Name is</h3><p>{user.name.first} {user.name.last}</p>
                </div>
              </div>
            );
          })
        }
      </Fragment>
    );
  } 
  return (
    <div className='main-content'>
      <div className='result-container'>
        <div className='user-details'>
          {componentToBeRender}
        </div>
      </div>
      <UserDetails open={showModal} toggleModal={handleUserClick} userDetails={user}/>
    </div>
  );
}

export default memo(Home);