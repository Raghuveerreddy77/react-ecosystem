import React from 'react';
import { render } from '@testing-library/react';
import Home from './Home';

describe('Home Page test cases', () => {
  const defaultProps = {
    users: [],
    isFetching: true
  }

  const users = [
    { 
      name: {title: 'Mr', first: 'first', last: 'last'},
      location: {country: 'counttry', state: 'state', city: 'city'},
      email: "email",
      phone: "phone",
      picture: {large: 'large', medium: 'medium'}
    }
  ];

  test('renders Home correctly when list is empty', () => {
    const { asFragment } = render(<Home {...defaultProps}/>);
    expect(asFragment()).toMatchSnapshot();
  });

  test('renders Home correctly with user details details', () => {
    const props = {...defaultProps, users: users};
    const { asFragment } = render(<Home {...props}/>);
    expect(asFragment()).toMatchSnapshot();
  });
});

