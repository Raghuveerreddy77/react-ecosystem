import {connect} from 'react-redux';
import Home from './Home';

const mapStateToProps = (state) => {
  return {
    users: state.users.users,
    isFetching: state.users.isFetching
  };
};

export default connect(mapStateToProps, null)(Home);
