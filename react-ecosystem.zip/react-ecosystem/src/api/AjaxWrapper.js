const BASE_PATH = 'https://randomuser.me/api/?results=';
const AjaxWrapper = {
  get: (query) => {
    return fetch(`${BASE_PATH}${query}`).then((res) => res.json())
    .then((response) => {
      return response;
    })
  }
};

export default AjaxWrapper;