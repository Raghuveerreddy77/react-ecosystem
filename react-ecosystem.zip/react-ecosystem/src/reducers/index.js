import {combineReducers} from 'redux';
import users from './sidebar';

export default combineReducers({users});