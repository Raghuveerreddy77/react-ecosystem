import { SET_USER_DETAILS, SET_LOADER } from "../actions/sidebar";

const defaultSchema = {
  users: [],
  isFetching: true
}

export default (state = defaultSchema, action) => {
  switch (action.type) {
    case SET_USER_DETAILS:
      return {...state, users: action.payload};
    case SET_LOADER:
      return {...state, isFetching: action.payload};
    default:
      return state;
  }
};