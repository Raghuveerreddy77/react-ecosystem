import sideBarReducer from './sidebar';
import {
  SET_USER_DETAILS, SET_LOADER
} from '../actions/sidebar';

const users = [
  { 
    name: {title: 'Mr', first: 'first', last: 'last'},
    location: {country: 'counttry', state: 'state', city: 'city'},
    email: "email",
    phone: "phone",
    picture: {large: 'large', medium: 'medium'}
  }
]

describe('side-bar reducer', () => {
  test('should return the initial state', () => {
    const initialState = {users: [], isFetching: true}
    expect(sideBarReducer(undefined, {})).toEqual(initialState);
  });

  test('should set users data', () => {
    const action = [
      {type: SET_LOADER, payload: true},
      {type: SET_USER_DETAILS, payload: []},
      {type: SET_LOADER, payload: false}
    ];
    const expectedState = {users: [], isFetching: true};

    expect(sideBarReducer(undefined, action)).toEqual(expectedState);
  });
});
